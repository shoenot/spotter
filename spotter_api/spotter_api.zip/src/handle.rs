use crate::queries::*;
use axum::{Json, extract::{Query, State}, http::StatusCode};
use chrono::{
    DateTime, Datelike, TimeZone, Utc
};
use sqlx::PgPool;
use serde::Deserialize;

#[derive(Deserialize)]
pub struct TopParams {
    from: Option<DateTime<Utc>>,
    to: Option<DateTime<Utc>>,
    lim: Option<i32>,
}

#[derive(Deserialize)]
pub struct HistoryParams {
    from: DateTime<Utc>,
    to: DateTime<Utc>,
}

fn resolve_top_params(params: TopParams) -> (DateTime<Utc>, DateTime<Utc>, i32) {
    let now = Utc::now();
    let from = params.from.unwrap_or_else(|| {
        Utc.with_ymd_and_hms(now.year(), now.month(), 1, 0, 0, 0).unwrap()
    });
    let to = params.to.unwrap_or(now);
    let lim = params.lim.unwrap_or(10);
    (from, to, lim)
}

pub async fn get_top_artists(State(pool): State<PgPool>, Query(params): Query<TopParams>)
    -> Result<Json<Vec<ListArtist>>, StatusCode> {
        let (from, to, lim) = resolve_top_params(params);
        match query_top_artists(&pool, from, to, lim).await {
            Ok(Some(vector)) => Ok(Json(vector)),
            Ok(None) => Ok(Json(vec![])),
            Err(_) => Err(StatusCode::INTERNAL_SERVER_ERROR)
        }
}

pub async fn get_top_albums(State(pool): State<PgPool>, Query(params): Query<TopParams>)
    -> Result<Json<Vec<ListAlbum>>, StatusCode> {
        let (from, to, lim) = resolve_top_params(params);
        match query_top_albums(&pool, from, to, lim).await {
            Ok(Some(vector)) => Ok(Json(vector)),
            Ok(None) => Ok(Json(vec![])),
            Err(_) => Err(StatusCode::INTERNAL_SERVER_ERROR)
        }
}
pub async fn get_top_tracks(State(pool): State<PgPool>, Query(params): Query<TopParams>)
    -> Result<Json<Vec<ListTrack>>, StatusCode> {
        let (from, to, lim) = resolve_top_params(params);
        match query_top_tracks(&pool, from, to, lim).await {
            Ok(Some(vector)) => Ok(Json(vector)),
            Ok(None) => Ok(Json(vec![])),
            Err(_) => Err(StatusCode::INTERNAL_SERVER_ERROR)
        }
}
pub async fn get_play_history(State(pool): State<PgPool>, Query(params): Query<HistoryParams>)
    -> Result<Json<Vec<ListPlay>>, StatusCode> {
        match query_play_history(&pool, params.from, params.to).await {
            Ok(Some(vector)) => Ok(Json(vector)),
            Ok(None) => Ok(Json(vec![])),
            Err(_) => Err(StatusCode::INTERNAL_SERVER_ERROR)
        }
}
pub async fn get_recents(State(pool): State<PgPool>) 
    -> Result<Json<Vec<ListPlay>>, StatusCode> {
    match query_recents(&pool).await {
        Ok(Some(vector)) => Ok(Json(vector)),
        Ok(None) => Ok(Json(vec![])),
        Err(_) => Err(StatusCode::INTERNAL_SERVER_ERROR)
    }
}
